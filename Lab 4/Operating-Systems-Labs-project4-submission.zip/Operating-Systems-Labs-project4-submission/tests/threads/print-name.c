/* Prints name when run */
#include <stdio.h>
#include "tests/threads/tests.h"

void
test_print_name (void) 
{
 
  msg("Linux RY");  

}
